package com.jaego.web.exception;

public class IdPasswordNotMatchingException extends RuntimeException {
	
}
